# FRAUDLENS — Delivery Canons
**Version** : 1.0
**Date**     : 2026-04-05
**Status**   : Authoritative — governs all commercial delivery, session lifecycle, and tier logic

---

## Canon D1 — Value First, Friction Last

The system must demonstrate forensic value before asking for anything.
Every upload is treated as a prospective client who needs to be convinced, not a paying
customer who has already committed.

The delivery model has two phases:

**Phase 1 — Free Proof**
Run as much as possible with zero cost: no GPU, no ML, no paid storage.
OpenCV passes only. Deliver a partial but defensible finding fast.
The goal is a candidate event on screen within minutes of upload.

**Phase 2 — Full Report Gate**
The complete report — annotated evidence clips, wall-clock event log, chain of custody,
PDF — is released only after payment is confirmed. Until then, the system shows enough
to create urgency, not enough to replace the purchase.

The pipeline always spends the minimum compute required to reach the next decision point.
No GPU is touched until the OpenCV passes have produced at least one candidate event.
No candidate event — no GPU spend.

---

## Canon D2 — The Funnel Is the Architecture

Processing is a sequential spend funnel. Each stage spends more than the last.
No stage executes unless the previous stage produced a positive signal.

```
Stage 0 — Upload + hash (H₀)         → zero GPU, minimal CPU, seconds
Stage 1 — OpenCV passes 0–3           → CPU only, no ML, no storage cost
Stage 2 — Candidate events identified → gate: at least 1 candidate? proceed. else: exit.
Stage 3 — Qwen pass on candidates     → GPU spend begins here
Stage 4 — LLaMA verdict               → GPU spend continues, only on FRAUD_SUSPECTED
Stage 5 — Report assembly + payment   → storage spend begins here
```

At every gate: if the signal does not justify the next spend, stop and exit.
Deliver what was found to that point. Log the session. Purge the video.

This is not a pipeline that always runs to completion.
Most sessions will exit at Stage 2 or Stage 3. That is correct behaviour, not failure.

---

## Canon D3 — Tool Priority Is Cost Priority

When multiple tools can answer the same question, choose the cheapest one first.
The order of preference is:

1. Pure OpenCV (CPU, free)
2. Alternative open-source CV libraries — scikit-image, SimpleCV, Kornia, any free-to-use library
3. Lightweight ML on CPU (ONNX runtime, small YOLO variants, MobileNet)
4. Qwen2-VL on GPU
5. LLaMA on GPU

A more expensive tool is only reached when the cheaper tool has demonstrably failed
or produced ambiguous output that cannot be resolved without the more expensive tool.
This applies to every pass, every zone, every frame decision.

The canons never mandate a specific library. If a free alternative does the same job
as a paid or GPU-bound tool, the free alternative is preferred.

---

## Canon D4 — Geography Is a First-Class Signal

Zone definition is not a configuration detail. It is a forensic judgment.
The system supports three zone definition methods, in order of preference:

**Method A — Qwen geography assist (onboarding)**
For new clients, Qwen is given the first clear keyframe and asked to identify:
counter surface, register / Yazar Kasa location, customer-facing area,
and any domain-specific elements (cigarette shelf, display case, safe, ATM).
Qwen's suggestion is presented to the operator as a draft. The operator confirms
or adjusts before any evidence run begins. Qwen geography suggestions are never
auto-committed without human confirmation.

**Method B — Zone Definer tool (manual)**
The zone_definer.html tool is used to draw zones on a reference frame.
The tool exports normalized 0.0–1.0 coordinates, resolution-independent.
This is the primary calibration method for any deployment.

**Method C — Predefined zone templates**
The Zone Definer tool ships with predefined templates for known environments:
- `gas_station_counter` — typical non-petroleum cashier layout
- `yazar_kasa_counter` — Turkish fiscal POS counter with receipt slot
- `tobacconist_shelf` — cigarette / tobacco display above counter
- `display_case` — glass case with luxury or high-value retail products

Templates are starting points. They must be adjusted to the actual camera frame
before any evidence run. Templates are never used unedited.

Domain context matters. A cigarette shelf is a different shrinkage surface than
a display case with watches. Zone labels and object classes in
`deployment_config.json` reflect the actual environment, not a generic retail template.

---

## Canon D5 — The Session Lifecycle

Every upload initiates a Volatile Forensic Session. Sessions have four possible states:

```
ACTIVE     → processing is running or awaiting user interaction
CANDIDATE  → at least one candidate event found, awaiting payment decision
PAID       → payment confirmed, full report released, data retained per contract
ABANDONED  → session inactive > configured timeout OR user explicitly exited without paying
```

**On ABANDONED:**
1. All video chunks and intermediate frames are deleted immediately.
2. GPU workers associated with the session are terminated.
3. The H₀ hash, session metadata, and the anonymised event log are retained.
4. The retained metadata is available for training use only (Canon D7).

**On PAID:**
1. Evidence package is sealed with manifest hash (H_m).
2. Full report PDF is released via payment-gated download link.
3. Video data is retained per the storage contract with the client.
4. Chain of custody log is frozen — no further modifications.

The H₀ hash is never deleted. It is the permanent proof that the file was seen.
If the same file is re-submitted later, the system recognises it immediately
and skips re-ingestion. The new session starts from Stage 2.

---

## Canon D6 — Tiers and Chunking

FraudLens operates across two delivery tiers:

**Paid tier (web app, PC app "lite")**
Full sequential pipeline. Upload → hash → OpenCV passes → candidate detection →
Qwen → LLaMA → full report gate. No chunking. The full file is processed
as a single session on the server. The client waits for results.

**Free tier (demo / prospect conversion)**
Chunking is permitted on the free tier only, as a UX concession to reduce
perceived wait time. The first chunk (configurable, default: first 15 minutes of footage)
is processed through OpenCV passes only. If a candidate event is found in the first chunk,
it is surfaced immediately to demonstrate value.

Chunking on the free tier must not compromise the chain of custody.
Each chunk receives its own hash and is logged against the parent H₀.
If chunking creates state continuity problems (drawer open at end of chunk,
receipt spanning chunk boundary), chunking is disabled for that session
and the full file is processed sequentially. Chunking is never used on paid sessions.

If chunking causes more operational complexity than it saves in user retention,
it is removed from the free tier without canon amendment.
Chunking is a UX feature, not an architectural commitment.

---

## Canon D7 — Metadata Is for Training, Not Surveillance

Session metadata retained after abandonment contains:
- H₀ hash (file fingerprint only — no reconstructible content)
- Session ID and timestamp
- Video technical parameters (resolution, fps, duration, codec)
- Number of candidate events found (count only)
- Zone coordinates used (anonymised — no client identifier attached)
- Pipeline stage reached before exit

This metadata is used exclusively for:
- Model training and pipeline improvement
- Re-submission recognition (H₀ lookup)
- Aggregate system performance reporting

It is never used to:
- Identify the client or the subject individuals
- Reconstruct any frame or segment of the original footage
- Build a profile of any person's behaviour across sessions

Metadata retained after ABANDONED sessions carries no client attribution.
The client name, location, and case reference are purged with the video.
What remains is forensically inert — useful for model improvement, useless for surveillance.

---

## Canon D8 — The Payment Gate Is Inviolable

The full report is never released before payment is confirmed.

"Full report" means: annotated evidence clips, wall-clock event log,
Qwen object detection outputs, LLaMA narrative verdict, chain of custody PDF.

The free-tier candidate preview may show:
- The timestamp of the candidate event (wall clock)
- The activity level at that timestamp (motion score)
- The zone where activity was detected
- A blurred or low-resolution still of the frame

The free-tier preview must never show:
- Unblurred frames of individuals
- LLaMA verdict text
- Downloadable video clips
- The chain of custody report

The payment gate is implemented at the report assembly stage, not at the display stage.
The backend never assembles the full report until payment_status = PAID.
Showing a preview is a frontend decision. Assembling the report is a backend event.
These two things are never coupled.

---

## Canon D9 — Delivery Is Infrastructure-Agnostic

The commercial delivery layer does not dictate the compute environment.
The same pipeline runs on:
- Cloud GPU instances (Thunder Compute or equivalent)
- Local dedicated server
- Future: portable field unit (to be specified separately)

Session lifecycle, payment gate, metadata retention, and tier logic
are defined in this document and do not change based on where the compute runs.
`deployment_config.json` contains the environment-specific overrides.
No delivery canon references a specific cloud provider, hostname, or API endpoint.

---

## Revision History

| Version | Date       | Author    | Changes                    |
|---------|------------|-----------|----------------------------|
| 1.0     | 2026-04-05 | FraudLens | Initial delivery canon document |

---

*This document is the authoritative reference for all FraudLens commercial delivery decisions.
Any implementation that conflicts with these canons requires a canon amendment, not
a code workaround. Canons D1–D9 operate alongside CANONS.md, ONBOARDING_CANONS.md,
and REPORTING_CANONS.md. In case of conflict, the detection canons (CANONS.md) take precedence
over delivery canons on all matters of forensic logic.*
