# FRAUDLENS — Reporting & Ethics Canons
**Version** : 1.0  
**Date**     : 2026-04-04  
**Status**   : Authoritative — all reporting, data handling, and ethical conduct must reference these canons  
**Companion documents** : CANONS.md (detection logic) · ONBOARDING_CANONS.md (client intake)

---

> *Reporting is the documentation of the Chain of Reason.*  
> *Every finding must be traceable. Every data action must be explainable.*  
> *Honor and honesty are not policies — they are the product.*

---

## Canon R-1 — Radical Auditability

Every action taken on client data — whether by an AI pass, an automated script,
or a human operator — is logged with a timestamp and full attribution. No action
is silent. No action is irreversible without a record.

**What is logged for every action:**
- Action type (pass execution, annotation, verdict, amendment, deletion)
- Actor (system pass ID, or human Operator ID)
- Timestamp (ISO 8601, UTC)
- Input state (what the data looked like before)
- Output state (what the data looks like after)
- Hash of the output (so any subsequent modification is detectable)

**The client's right to a Full Audit Trace:**  
The client may request a complete audit log at any time during or after the engagement.
The audit log is delivered within 48 hours of request. It covers every action taken
on their data from H₀ to delivery of the final report.

The audit log is not a summary. It is the raw, timestamped, operator-attributed
record of every system and human decision made in their case.

This right does not expire. The audit log is retained for the same duration as the
evidence package (defined in the retention contract, minimum 5 years for sealed evidence).

---

## Canon R-2 — Pre-Intake Retention Lock

What is kept and what is erased is agreed, signed, and locked in a **Data Retention
Contract** before the first byte of footage is uploaded. This contract is Section 0
of the Onboarding Report — it precedes even H₀.

**Standard retention schedule:**

| Data type                        | Retention period              | Deletion method          |
|----------------------------------|-------------------------------|--------------------------|
| Non-flagged footage (redacted)   | X days (client-defined)       | Secure overwrite         |
| Pass output metadata             | Duration of engagement + 90d  | Secure overwrite         |
| Flagged segments (unredacted)    | Duration of legal hold        | Court-ordered only       |
| Sealed evidence packages         | Minimum 5 years               | Court-ordered only       |
| Audit logs                       | Same as evidence package      | Never unilaterally       |
| Training store records           | Indefinite (no PII — see R-4) | Client request + review  |

**The No-Surprise guarantee:**  
No data is retained beyond the agreed schedule without written client consent and
an Amendment Event (Canon O-8). No data is used for any purpose not specified in
the retention contract. The contract is the Budget; the Final Report confirms the Actuals.
Any divergence between Budget and Actuals is a breach of the engagement.

---

## Canon R-3 — Redaction-at-Ingest — Blur First

FraudLens operates on a **Blur-First** principle. PII redaction is not a post-processing
step — it is the first transformation applied to any frame before it is written to
persistent storage.

**What is redacted:**
- Human faces (Gaussian blur, configurable radius)
- License plates (where visible)
- Any personally identifying text visible in frame (ID cards, documents)

**When redaction applies:**
- All footage at Pass 0/1, before any frame is stored.
- The unredacted original resides only in the upload buffer during transfer.
- Once H₀ is verified and the file is received, the unredacted original is never
  written to persistent disk.

**The single exception:**  
A segment that receives a `FRAUD_SUSPECTED` or `SHRINKAGE_SUSPECTED` verdict AND
is subsequently sealed as an evidence package retains the unredacted frames within
that package only. These frames are:
- Stored in an encrypted, access-logged vault.
- Accessible only by authorized FraudLens operators and the client's designated counsel.
- Subject to the legal hold provisions of the retention contract.
- Never used for training purposes (see R-4).

**The legal position this creates:**  
"We never wrote the face to disk" is a categorically different legal position from
"we wrote it and then deleted it." The first never creates a data subject right under
KVKK or GDPR. The second does. Blur-First is not a privacy feature — it is a legal
architecture decision.

---

## Canon R-4 — The Metadata Training Wall

FraudLens trains its models exclusively on metadata. No raw footage, no face, no voice,
no biometric feature, and no personally identifying information ever enters a training
record. This is absolute and has no exceptions.

**What the training store contains:**
- Bounding box coordinates (normalized 0.0→1.0, no pixel data)
- Zone motion scores (percentages, no pixel data)
- Frame timestamps and segment IDs (no content, only timing)
- Object class labels (e.g. "cash", "hand" — not "whose hand")
- Operator-confirmed binary verdicts (FRAUD / CLEAN / INCONCLUSIVE)

**What the training store never contains:**
- Any image or video frame
- Any face or body feature
- Any audio
- Any name, location, or identifying context from the client engagement
- Any unredacted frame from a sealed evidence package

**Client disclosure:**  
The use of anonymized metadata for model improvement is disclosed in the retention
contract before intake. The client is told specifically what categories of metadata
may be used and retains the right to opt out. Opting out does not affect the quality
of their analysis — it only affects contribution to future model versions.

**The training store is auditable:**  
The client may request a description of what metadata records, if any, were derived
from their engagement. They will receive a count, a category breakdown, and confirmation
that no PII is present. They will not receive the records themselves (which belong to
the proprietary training corpus) but they will receive proof of compliance.

---

## Canon R-5 — The Judge-Ready Narrative

The language model output (Pass 5) is written for a trier of fact — a judge, a
magistrate, or legal counsel — not for an engineer. Technical terms are explained.
Jargon is avoided. The chain of reason is explicit.

**Required narrative structure:**

```
1. Segment identification
   "This report covers the segment beginning at [wall clock time] on [date],
   reference [segment_id]."

2. Observable facts — what the system detected
   "At [timestamp], an object classified as [label] with confidence [X]%
   was detected in the [zone] zone (frame [frame_id])."

3. Oracle state — what the system observed about the oracle
   "Between [T_object] and [T_object + response_window], the [oracle_type]
   oracle registered [no activity / activity at T_oracle]."

4. System classification — the technical verdict
   "Based on the absence of a primary oracle event within the configured
   [N]-second response window, the system has classified this segment as
   [FRAUD_SUSPECTED / LEGIT / INCONCLUSIVE]."

5. Limitations acknowledgment
   "This classification is based on observable system states only. It is
   a probabilistic finding, not a legal conclusion. Human review is required
   before this finding is used in any legal or disciplinary proceeding."
```

**The language boundary — what the narrative must never say:**

The narrative documents observable system states only. It never asserts legal
conclusions, intent, or guilt.

| Prohibited language              | Correct language                                      |
|----------------------------------|-------------------------------------------------------|
| "The cashier stole the money"    | "The drawer oracle did not fire within the window"    |
| "Fraud was committed"            | "The segment is classified FRAUD_SUSPECTED"           |
| "The employee is guilty"         | "Human review is required to evaluate this finding"   |
| "This proves theft"              | "No primary oracle event was detected"                |

The word **"fraud"** does not appear in the narrative body. It appears only in the
technical verdict field (`preliminary_verdict`) as a system classification label,
not as a finding of fact. The distinction between a system classification and a
legal finding must be explicitly stated in every report that contains a
`FRAUD_SUSPECTED` verdict.

---

## Canon R-6 — Jurisdictional Compliance

Each deployment operates under a defined legal jurisdiction specified in
`deployment_config.json`. The jurisdiction selection is not cosmetic — it
automatically governs the following:

**Under KVKK (Turkey) — default:**
- Data subjects have the right to know their data is being processed.
- Explicit consent is required for processing of sensitive personal data.
- Cross-border data transfer requires KVKK Board approval or standard contractual clauses.
- Breach notification is mandatory within 72 hours.
- Retention periods must be proportionate to the processing purpose.

**Under GDPR (EU) — available profile:**
- All KVKK provisions apply, plus:
- Right to erasure (Article 17) — honored within 30 days of valid request.
- Data Protection Impact Assessment (DPIA) may be required for systematic monitoring.
- Data Processing Agreement (DPA) required with FraudLens as data processor.
- Data Protection Officer (DPO) designation may be required on client side.

**Redaction intensity by jurisdiction:**
- KVKK: faces blurred in all non-evidence footage.
- GDPR: faces blurred + metadata minimized + purpose limitation strictly enforced.

The jurisdiction cannot be changed after the retention contract is signed without
a formal Amendment Event and a re-evaluation of all data already collected.

---

## Canon R-7 — The No-Surprise Doctrine

The Onboarding Report is the **Budget** of what FraudLens will do with client data.
The Final Report is the **Actuals** — what was actually done.
These two documents must be consistent in every material respect.

**What constitutes a material divergence:**
- Data retained longer than the agreed schedule.
- Data used for a purpose not disclosed in the retention contract.
- Analysis performed on footage beyond the agreed scope.
- Training records created from an engagement where the client opted out.
- Any PII retained in storage beyond the agreed purge date.

**What happens when a divergence is discovered:**
1. The divergence is logged immediately in the audit trail.
2. The client is notified within 24 hours with a full explanation.
3. Corrective action is taken and documented.
4. If the divergence constitutes a data breach under the applicable jurisdiction,
   the mandatory notification timeline applies (72 hours under KVKK and GDPR).
5. The incident is recorded permanently in the engagement audit log.
   It cannot be redacted or removed.

A divergence discovered and self-reported by FraudLens is a different legal and
ethical event from a divergence discovered by the client or a regulator. Self-reporting
is mandatory. It is also the honorable course.

---

## Canon R-8 — The Final Report Structure

Every completed engagement produces a Final Report that is the consolidated,
signed, court-ready document of the entire case.

**Mandatory sections:**

```
Section 0  — Data Retention Agreement (reference to signed contract)
Section 1  — Video Intake and H₀ Certificate
             (hash, file metadata, ingestion timestamp, operator ID)
Section 2  — Geometry and Zone Confirmation
             (reference frame hashes, zone coordinates, calibration status)
Section 3  — Event Definition and Configuration Lock
             (decision tree answers, config values, operator sign-off)
Section 4  — Analysis Work Plan
             (passes executed, models used, sensitivity profile, dates)
Section 5  — Findings
             (one sub-section per flagged segment — see R-5 narrative structure)
Section 6  — Evidence Inventory
             (list of all sealed evidence packages, their H_m values, locations)
Section 7  — Data Disposition
             (what was kept, what was deleted, when, confirmed against R-2 contract)
Section 8  — Audit Trail Summary
             (count of actions by type, operator IDs involved, date range)
Section 9  — Limitations and Disclaimers
             (probabilistic nature of findings, human review requirement,
              no legal conclusions, jurisdiction-specific disclosures)
```

The Final Report is signed with H_report — a SHA-256 hash of the complete document.
Any modification to the report after signing produces a different hash, immediately
detectable by any party who retained a copy of H_report.

---

## Canon R-9 — Operator Accountability

Every human action in the FraudLens system is attributed to a named, credentialed
operator. Operators are not anonymous. Operators cannot delegate their Operator ID.

**Operator responsibilities:**
- Reviewing and signing configuration decisions (especially free-text client input).
- Reviewing and confirming AI verdicts before evidence packages are sealed.
- Executing deletion events and confirming data disposition.
- Authorizing and logging amendment events.
- Signing each section of the onboarding and final reports.

**What operators may never do:**
- Sign off on a verdict they have not personally reviewed.
- Use another operator's ID for any action.
- Delete an audit log entry.
- Alter a sealed evidence package.
- Approve a configuration that conflicts with the client's stated intent without
  flagging the discrepancy in the audit log.

Operator conduct is itself auditable. A client who believes an operator acted
improperly may request the operator's action log for the engagement. FraudLens
will provide it.

---

## Revision History

| Version | Date       | Author    | Changes              |
|---------|------------|-----------|----------------------|
| 1.0     | 2026-04-04 | FraudLens | Initial document     |

---

*This document governs all reporting, data handling, and ethical conduct.*  
*Any process that deviates from these canons requires a canon amendment,*  
*not a process workaround.*  

*Honor and honesty are not policies. They are the product.*
