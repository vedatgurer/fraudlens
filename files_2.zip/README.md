# FraudLens — Forensic CCTV Analysis

**FraudLens** is a forensic video analysis system designed to detect unregistered
cash transactions and inventory shrinkage in retail and gas station environments.
It is a post-analysis tool — not real-time surveillance — built for legal admissibility.

---

## What FraudLens Does

FraudLens analyzes recorded CCTV footage to detect the moment a cash transaction
occurs without triggering a register event (drawer open). It does not accuse. It
documents observable system states. A human reviewer makes every final determination.

**Core detection logic:**
```
Cash object detected → Did the drawer open within the configured window?
  YES → LEGIT. Archived.
  NO  → FRAUD_SUSPECTED. Forensic package generated for human review.
```

---

## Project Canon Library

The canon documents below are the authoritative reference for all design decisions.
They are public by design — transparency in forensic methodology builds trust.

| Document | Scope | Status |
|----------|-------|--------|
| [CANONS.md](docs/CANONS.md) | Detection logic, pipeline architecture, model design | Public |
| [ONBOARDING_CANONS.md](docs/ONBOARDING_CANONS.md) | Client intake, chain of custody from first byte | Public |
| [REPORTING_CANONS.md](docs/REPORTING_CANONS.md) | Audit trail, KVKK/GDPR compliance, ethics | Public |

Any implementation that conflicts with these canons requires a canon amendment,
not a code workaround.

---

## Core Principles

- **Forensic tool, not a judge.** Every verdict is probabilistic. Human review is mandatory.
- **Drawer is the sole oracle.** A cash drawer open event is the only signal that proves a cash transaction was registered. Receipt state is context, not verdict.
- **No ML unless OpenCV fails.** Five passes of pure pixel analysis run before any GPU inference.
- **Blur first, store after.** PII is redacted before any frame is written to persistent storage.
- **Metadata trains the models, never footage.** No face, voice, or biometric feature enters a training record.
- **Radical auditability.** Every action on client data is logged, timestamped, and operator-attributed.
- **Honor and honesty are the product.** The onboarding agreement is the budget. The final report is the actuals. They must match.

---

## Pipeline Architecture

```
Pass 0  — MOG2 motion scan              (OpenCV)
Pass 1  — Idle segment filter           (OpenCV)
Pass 2  — Per-zone motion scoring       (OpenCV)
Pass 3  — Drawer + receipt state machine (OpenCV)
Pass 3.5— Zone-crossing logic           (OpenCV, optional)
Pass 4  — Visual object confirmation    (Qwen2-VL, GPU A)
Pass 5  — Temporal reasoning + verdict  (LLaMA, GPU B)
```

Qwen is called only on flagged segments. LLaMA is called only when Qwen confirms
a target object and the primary oracle did not fire.

---

## Deployment Domains

- **Retail** — Yazar Kasa counter, overhead fisheye camera
- **Gas station** — non-petroleum cashier counter

All deployment parameters (zones, thresholds, oracle types, jurisdictions) are
defined in `deployment_config.json`. The pipeline code contains no hardcoded values.

---

## Compliance

- **KVKK** (Turkey) — default jurisdiction
- **GDPR** (EU) — available deployment profile
- Evidence packages prepared as attorney work product by default
- SHA-256 chain of custody: H₀ (ingest) → H_a (annotation) → H_m (manifest)

---

## Repository Structure

```
fraudlens/
├── docs/
│   ├── CANONS.md
│   ├── ONBOARDING_CANONS.md
│   └── REPORTING_CANONS.md
├── deployments/
│   └── tezer_retail/
│       └── deployment_config.json   ← anonymized template
└── README.md
```

Scripts, training pipelines, and model weights are not public.

---

## Status

Active development. Phase 1 POC underway on first client deployment.

---

*FraudLens is a forensic evidence tool. It is not a surveillance system.*
*It does not operate in real time. It does not make legal conclusions.*
*Every finding requires human review before any legal or disciplinary action.*
