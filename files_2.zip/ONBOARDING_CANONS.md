# FRAUDLENS — Onboarding Canons
**Version** : 1.0  
**Date**     : 2026-04-04  
**Status**   : Authoritative — all client intake procedures must reference these canons  
**Companion documents** : CANONS.md (detection logic) · REPORTING_CANONS.md (audit and ethics)

---

> *Onboarding is the first act of evidence creation, not a sales hurdle.*  
> *The chain of custody begins at the first byte, not at the first finding.*

---

## Canon O-1 — H₀ Ingestion Mandate

The forensic record begins at the **First Byte**. Before any analysis, zone definition,
or configuration occurs, a Root Hash (H₀) is computed for the entire source file using
SHA-256. This hash is the immutable fingerprint of the client's original footage.

- H₀ is computed client-side from the first chunk before upload begins.
- H₀ is re-verified server-side after the final chunk is received.
- If H₀ client ≠ H₀ server, the upload is rejected and the engagement does not proceed.
- H₀ is displayed to the client in the onboarding UI and printed in Section 1 of the
  Onboarding Report. The client can verify it independently at any time using any
  standard SHA-256 tool.

The Onboarding Report is technically **Section One of the final Evidence Package**.
It is not a preliminary document — it is the beginning of the case file.

---

## Canon O-2 — Concurrent Processing Logic

Client wait time during upload is eliminated by running onboarding tasks in parallel
with the upload stream. The UI is never a waiting screen.

**Concurrent task map:**

```
UPLOAD RUNNING                    CLIENT DOING
──────────────────────────────    ──────────────────────────────────────────
Chunk 1 received → H₀ started    Client labels the engagement (location, date, shift)
Chunk 2–N uploading               Client loads reference frame → draws zones
Upload 50% complete               Client confirms geometry, names zones
Upload 80% complete               Client completes decision tree (O-3)
Upload 100% → H₀ verified        Onboarding report sections 1–3 already signed
Pass 1 begins immediately         Client reviews onboarding report section 4
```

The `deployment_config.json` is populated field-by-field as each onboarding stage
completes. By the time the upload finishes, the config is ready and Pass 1 can begin
without delay.

---

## Canon O-3 — The 90/10 Decision Tree

To minimize configuration drift and human error, four structured questions cover
90% of all deployment configurations. Questions are presented in plain language.
No technical knowledge is required from the client.

### The four questions

**Q1 — Environment**
```
What best describes your setup?
  A) Retail counter with fiscal printer (Yazar Kasa or equivalent)
  B) Gas station — non-fuel cashier counter
  C) Warehouse or stockroom
  D) Other — please describe
```
Maps to: `deployment_domain`, camera geometry expectations, zone label defaults.

**Q2 — Legitimate transaction**
```
When a normal, legitimate cash sale happens, what do you see?
  A) Cashier opens the drawer and a receipt prints
  B) No drawer opens (card-only environment)
  C) Both methods are used — cash and card
  D) Other — please describe
```
Maps to: `primary_oracle.type`, `secondary_oracle.type`, fraud signal matrix selection.

**Q3 — Suspected behavior**
```
What are you trying to detect?
  A) Cash accepted by cashier but not registered (drawer never opens)
  B) Items leaving the counter without being scanned
  C) Both of the above
  D) Something else — please describe
```
Maps to: `fraud_patterns.pattern_a_enabled`, `fraud_patterns.pattern_b_enabled`,
`services.inventory_tracking`.

**Q4 — Frequency estimate**
```
How often do you believe this is happening?
  A) Rarely — I have a specific incident in mind
  B) Sometimes — I suspect ongoing behavior
  C) Frequently — I believe this is systematic
  D) I don't know yet
```
Maps to: `models.sensitivity_profile`  
A → `strict_evidence` (τ = 0.85)  
B → `balanced` (τ = 0.65)  
C → `high_vigilance` (τ = 0.45)  
D → `balanced` (τ = 0.65, flagged for operator review)

### The Human-in-the-Loop Rule

Any answer of type D (free text) in any question triggers a `HUMAN_REVIEW_REQUIRED`
flag in the project record. The following rules apply without exception:

- Pass 1 does not begin until the flag is resolved.
- A FraudLens operator reads the client's free-text description.
- The operator makes the configuration decision and logs their Operator ID and timestamp.
- No AI system may interpret client intent regarding legal or fiscal boundaries.
- The operator's decision is appended to the onboarding report as a signed amendment.

This rule exists because a client saying "the cashier does something funny with the
cigarettes" is a legal statement of suspicion, not a technical specification. A human
must bridge that gap. The operator who bridges it takes professional responsibility
for the configuration choice they make.

---

## Canon O-4 — Incremental Report Signing

The onboarding report is generated and cryptographically signed **section by section**
as each stage completes. The client sees the record being built in real time.

**Report generation sequence:**

| Stage completes       | Report section generated and signed          | Signed with |
|-----------------------|----------------------------------------------|-------------|
| Upload begins         | Section 1: Video intake and H₀ fingerprint   | H₀          |
| Zone definition done  | Section 2: Geometry and zone confirmation    | H_zone      |
| Decision tree done    | Section 3: Event definition and config lock  | H_config    |
| Pass 1 begins         | Section 4: Work plan and analysis scope      | H_manifest  |

Each section is signed independently. A client who completes only stages 1 and 2 has
a partial but valid forensic record of what was ingested and how the geometry was
defined — even if the engagement does not proceed further.

The client does not wait for a final PDF. Each section is available for download
immediately after it is signed.

---

## Canon O-5 — First-Act Evidence Capture

Still frames extracted during zone definition are the **first annotated evidence**
in the case. They are not preview thumbnails. They are forensic reference frames.

- Each frame is extracted at a defined timestamp and labeled with that timestamp.
- Each frame is hashed (H_frame) immediately after extraction.
- The frame hash, timestamp, and extraction method are recorded in the chain of custody.
- Zone coordinates drawn on these frames are stored as a separate annotation layer —
  not burned into the frame itself. The original frame pixel data is never modified.
- These frames are referenced in the deployment config as the calibration ground truth.
- If zone coordinates are ever amended, the original frames and their hashes are
  retained alongside the amendment record (see Canon O-7).

---

## Canon O-6 — Geometry vs. Detection — Separation of Powers

A strict boundary exists between what the client contributes and what FraudLens
contributes. Neither party can perform the other's function.

**The client defines:**
- Physical boundaries — where on the screen the counter, register, and customer area are.
- What they see in their own environment.
- What a normal transaction looks like to them.

**FraudLens defines:**
- How those boundaries translate into normalized detection coordinates.
- What pixel-level signatures constitute oracle events.
- What thresholds govern the detection logic.

**The Seal:**  
Once the onboarding report Section 2 is signed, the zone coordinates are locked.
Neither the client nor FraudLens can alter them without a formal Amendment Event
(Canon O-7). This protects both parties:

- The client cannot later claim zones were drawn incorrectly by FraudLens.
- FraudLens cannot later be accused of shifting zones to produce desired results.

---

## Canon O-7 — Upload Integrity and Failure Protocol

Upload failures are a forensic event, not just a technical inconvenience.
The following rules govern incomplete or interrupted uploads:

- **Partial uploads are not analyzed.** Pass 1 does not begin on an incomplete file.
- **Each chunk is hashed on receipt.** A chunk hash mismatch triggers immediate
  rejection of that chunk and a re-upload request. The engagement record logs the event.
- **If an upload is abandoned** after H₀ has been issued, the engagement record is
  marked `UPLOAD_INCOMPLETE`. The partial H₀ is retained in the audit log but flagged
  as unverified. The engagement cannot produce evidence.
- **If the client re-uploads** the same file, a new H₀ is computed. If H₀ matches the
  previous attempt, continuity is confirmed and logged. If H₀ differs, the client is
  notified that the files are not identical and the discrepancy is logged.
- **Storage quota exceeded** is treated as an upload failure. The client is notified
  before the upload begins if projected file size exceeds available quota.

---

## Canon O-8 — Amendment Events

Any post-seal change to onboarding data — zone coordinates, event definition, config
values, or retention terms — constitutes a formal Amendment Event.

An Amendment Event requires:

1. Written request from the client stating what they want to change and why.
2. FraudLens operator review and approval, logged with Operator ID and timestamp.
3. A new signed document appended to the onboarding report:
   - Original value
   - Amended value
   - Reason for amendment
   - Authorizing operator ID
   - Timestamp
4. If zone coordinates are amended: new reference frames must be extracted, hashed,
   and added to the chain of custody alongside the original frames.
5. If the amendment materially affects the detection scope, Pass 1 must be re-run
   on the full footage from the beginning.

An amendment does not erase the original record. Both the original and the amended
values are permanently retained in the audit log.

---

## Canon O-9 — Client Identity and Engagement Record

Every engagement receives a unique reference before any data is transferred.

**Engagement record minimum fields:**
```
engagement_ref    : FL-YYYYMMDD-NNN (system generated)
client_id         : anonymized internal reference
client_label      : human-readable location or entity label
operator_id       : FraudLens operator who opened the engagement
opened_at         : ISO 8601 timestamp
jurisdiction      : governing privacy regulation
service_tier      : forensic | full_spectrum
H0                : SHA-256 of source file (populated at upload completion)
status            : ONBOARDING | ACTIVE | COMPLETE | SUSPENDED | DISPUTED
```

The engagement reference is printed on every document, every report section, every
evidence package, and every email communication related to this case. It is the
single thread connecting all artifacts.

---

## Revision History

| Version | Date       | Author    | Changes              |
|---------|------------|-----------|----------------------|
| 1.0     | 2026-04-04 | FraudLens | Initial document     |

---

*This document governs all client intake procedures. Any onboarding process that*
*deviates from these canons requires a canon amendment, not a process workaround.*
